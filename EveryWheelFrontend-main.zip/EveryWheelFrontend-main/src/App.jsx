import { Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Map from './pages/Map';
import Register from './pages/Register';
import Profile from './pages/Profile';
import { UserAuthContextProvider } from '/src/pages/context/UserAuthContext.jsx'

function App() {

  return (
    <UserAuthContextProvider>
      <Routes>
        <Route path="/" element={<Login/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path="/map" element={<Map/>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/profile" element={<Profile/>}/>
      </Routes>
      </UserAuthContextProvider>
  )
}

export default App
