import { useState } from "react";
import app from "./Firebase";
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';

function Register() {
  const auth = getAuth(app);
  const [user, setUser] = useState({
    Email: '', Password: '', Name: '', Surname: '', Picture: '', Tel: ''
  });
  let navigate = useNavigate();

  // This function will be triggered when inputs change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  // This function will be triggered when the form is submitted
  const handleRegister = (e) => {
    e.preventDefault();
    createUserWithEmailAndPassword(auth, user.Email, user.Password)
      .then((credentials) => {
        console.log(credentials);
        navigate("/");
        // You might want to save the additional user details to the database here
        // Handle the success case, maybe update the UI or navigate to another page
      })
      .catch((error) => {
        alert(error.message); // Show the error to the user
        console.error(error.code); // Log the error code for debugging
        console.error(error.message); // Log the full error message for debugging
        // Handle the error case, maybe show a message to the user
      });
  };

    return (
        <div className="bg-cover min-h-screen bg-[#ffedcc]">
        <div className="grid grid-row-3">
            
        <div class=" mt-36 row-span-1 flex justify-center items-center">
            <h1 className="text-3xl font-black font-sans">REGISTER</h1>
        </div>

        <div class="mt-12 row-span-1  p-3 flex justify-center items-center">
        <input type="email" placeholder="Email" name="Email" className="input input-bordered w-full max-w-xs" value={user.Email}onChange={handleInputChange} />
        </div>

        <div class="row-span-2  p-3 flex justify-center items-center">
        <input type="password" placeholder="Password" name="Password" className="input input-bordered w-full max-w-xs" value={user.Password} onChange={handleInputChange}/>
        </div>

        <div class="row-span-3  p-3 flex justify-center items-center">
        <input type="text" placeholder="Name" name="Name" className="input input-bordered w-full max-w-xs" value={user.Name} 
        onChange={handleInputChange}
        />
        </div>

        <div class="row-span-3  p-3 flex justify-center items-center">
        <input type="text" placeholder="Surname" name="Surname" className="input input-bordered w-full max-w-xs" value={user.Surname} 
        onChange={handleInputChange}
        />
        </div>

        <div class="row-span-3  p-3 flex justify-center items-center">
        <input type="text" placeholder="Picture" name="Picture" className="input input-bordered w-full max-w-xs" value={user.Picture} 
        onChange={handleInputChange}
        />
        </div>

        <div class="row-span-3  p-3 flex justify-center items-center">
        <input type="tel" placeholder="Tel" name="Tel" className="input input-bordered w-full max-w-xs" value={user.Tel} 
        onChange={handleInputChange}
        />
        </div>

        <div class="p-3 flex justify-center items-center h-full">
        <button class="btn btn-xs w-40 h-3 " type="submit" onClick={handleRegister} >Confirm</button>
        </div>


        </div>

      </div>
)}
export default Register;