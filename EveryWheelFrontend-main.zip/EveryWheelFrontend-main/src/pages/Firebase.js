// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import {getAuth} from "firebase/auth";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyACiXAYUeHY7ikaeRb2TVfoJdTM9OJidPY",
    authDomain: "everywheelfrontend.firebaseapp.com",
    projectId: "everywheelfrontend",
    storageBucket: "everywheelfrontend.appspot.com",
    messagingSenderId: "546426147724",
    appId: "1:546426147724:web:09022dea2cb673fa6f7ca9",
    measurementId: "G-B11PZ0DC9L"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const auth = getAuth(app);
export const db = getFirestore(app);

export default app;

