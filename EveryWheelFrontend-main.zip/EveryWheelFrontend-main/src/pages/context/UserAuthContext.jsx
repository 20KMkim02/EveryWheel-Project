import React, { createContext, useState, useEffect, useContext } from 'react';
import { auth } from '/src/pages/Firebase.js'; // Import your Firebase auth module
import { createUserWithEmailAndPassword,signInWithEmailAndPassword,onAuthStateChanged, signOut} from "firebase/auth";
import { useCookies } from 'react-cookie';
// Create the context

const userAuthContext = createContext();

export function UserAuthContextProvider({ children }) {
    const [cookie, setCookie] =useCookies();
    const [user, setUser] = useState({});

    function logIn(email, password) {
        return signInWithEmailAndPassword(auth, email, password);
    }

    function signUp(email, password) {
        return createUserWithEmailAndPassword(auth, email, password);
    }

    function logOut() {
        return signOut(auth);
    }

    useEffect(() => {

        const unsubscribe = onAuthStateChanged(auth, (currentuser) => {
       setCookie('token', currentuser.email)     
       setUser(currentuser);
        })

        return () => {
            unsubscribe();
        }

    }, [])

  return (
    <userAuthContext.Provider value={{ user, logIn, signUp, logOut }}>
        {children}
    </userAuthContext.Provider>
  )
}

export function useUserAuth() {
    return useContext(userAuthContext);
}
