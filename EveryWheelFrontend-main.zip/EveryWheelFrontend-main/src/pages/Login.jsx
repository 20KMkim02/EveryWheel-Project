// src/pages/Login.jsx
import React, { useState } from 'react';
import { GrMail } from 'react-icons/gr';
import { BiSolidKey } from 'react-icons/bi';
import logo from '/src/assets/LogoCrop.png'; // Adjust the path to your assets
import { Link, useNavigate } from 'react-router-dom'
import { Form, Button } from 'react-bootstrap'
import { useUserAuth } from './context/UserAuthContext'

import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';


function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const { logIn } = useUserAuth();

    let navigate = useNavigate();

    const [openSnackbar, setOpenSnackbar] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState('');
    const [severity, setSeverity] = useState('error'); // 'success', 'info', 'warning', 'error'

    // Handle closing the Snackbar
    const handleCloseSnackbar = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpenSnackbar(false);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        try {
            await logIn(email, password);
            navigate("/Map");
        } catch (err) {
            setSnackbarMessage("Error: incorrect email or password.");
            setSeverity("error");
            setOpenSnackbar(true);
           
        }
    };
    const register = async () => {
        try {
          navigate("/register");
        } catch (err) {
            console.log("Error: ", err);
           
        }
    };


    return (
        <div className="bg-cover bg-[#ffedcc] min-h-screen grid place-items-center">

            <div className="space-y-4 w-full max-w-sm p-4">
                <div className="avatar flex justify-center">
                    <div className="w-24 rounded-full">
                        <img src={logo} alt="Logo" />
                    </div>
                </div>
                <div className="text-center">
                    <h1 className="text-2xl font-black font-sans">EveryWheel</h1>
                    <p className="text-sm">Log in to your account and start moving around the city effectively.</p>
                </div>

                <Form onSubmit={handleSubmit} className="space-y-3 flex flex-col items-center">

                    <div className="flex items-center">
                        <GrMail className="text-3xl mr-4" />
                        <input
                            type="email"
                            name="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="Email"
                            className="input input-bordered flex-2"
                            required
                        />
                    </div>

                    <div className="flex items-center">
                        <BiSolidKey className="text-3xl mr-4" />
                        <input
                            type="password"
                            name="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Password"
                            className="input input-bordered flex-2"
                            required
                        />
                    </div>

                    <Button variant="primary" type="submit" onClick={handleSubmit} className="btn w-3/4 btn-active btn-neutral">Login</Button>

                    <Snackbar open={openSnackbar} autoHideDuration={6000} onClose={handleCloseSnackbar}  anchorOrigin={{ vertical: 'top', horizontal: 'center' }}>
                        <Alert onClose={handleCloseSnackbar} severity={severity} sx={{ width: '100%'}}>
                            {snackbarMessage}
                        </Alert>
                    </Snackbar>
                  
                </Form>


                {/* <a href="#" className="label-text-alt link link-hover ml-36">Forgot password?</a> */}

                <div className="divider text-[#f80]">OR USE</div>

                {/* Implement social login buttons here if needed */}

                <div className="flex justify-center">
                    <h3 className="text-[#f80]">Don't have an account?</h3>
                    <a href="#" onClick={register} className="link link-hover ml-2">Sign In</a>
                </div>
            </div>
        </div>
    );
}

export default Login;
