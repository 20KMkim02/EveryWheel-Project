import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import { collection, addDoc, getDocs } from "firebase/firestore";
import { db } from './Firebase';
import { useCookies } from 'react-cookie';
import { useNavigate } from 'react-router-dom'

function Map() {
  const [keyword, setKeyword] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);
  const [destination, setDestination] = useState({ lat: null, lon: null });
  const [map, setMap] = useState(null);
  const mapKey = '8a1f610d0c69063261331bf6d2afd0b9'; // Replace with your actual Map key from Longdo Map API
  const markerRef = useRef(null);
  const [destPlace, setDestPlace] = useState('');
  const [cookies, setCookie, removeCookie] = useCookies(['token']);
  const [faveRoute, setFaveRoute] = useState(['chulalongkorn university', 'siam paragon', 'central world']);
  const navigate = useNavigate();

  const AddFavRoute = async () => {
    try {
      const docRef = await addDoc(collection(db, "favRoute"), {
        email: cookies.token,
        place: destPlace,
        lat: destination.lat,
        lon: destination.lon
      });
      console.log("Document written with ID: ", docRef.id);
    } catch (e) {
      console.log("db", db)
      console.error("Error adding document: ", e);
    }

  }

  const getFavRoute = async () => {
    const querySnapshot = await getDocs(collection(db, "favRoute"));
    const places = []; // Initialize an empty array to collect place names
    querySnapshot.forEach((doc) => {
      if (doc.data().email === cookies.token) {
        places.push(doc.data().place); // Add place name to the array if the email matches
      }
    });

    setFaveRoute(places); // Set faveRoute state to the array of collected places
    console.log("faveRoute", places); // Log the array of places
  };
  useEffect(() => { getFavRoute() }, [faveRoute]);

  // Function to initialize the map
  const initMap = () => {
    const mapInstance = new window.longdo.Map({
      placeholder: document.getElementById('longdo-map'),
      language: 'th',
      zoom: 9, // Set the default zoom level
      lastView: false, // Do not restore the last view by default
    });
    setMap(mapInstance);
  };

  // Load the Longdo Map script and initialize the map
  useEffect(() => {
    if (!window.longdo) {
      const script = document.createElement('script');
      script.src = `https://api.longdo.com/map/?key=${mapKey}`;
      script.id = 'longdoMapScript';
      document.body.appendChild(script);

      script.onload = () => {
        initMap();
      };
    } else {
      initMap();
    }
  }, [mapKey]);

  // Function to search for places
  const searchApi = () => {
    if (keyword.trim()) {
      axios.get(`https://search.longdo.com/mapsearch/json/suggest?keyword=${keyword}&area=10&span=100km&limit=20&key=${mapKey}`)
        .then((res) => {
          setSuggestions(res.data.data.slice(0, 5));
          setIsDropdownVisible(true);
        }).catch((error) => {
          console.error(error);
        });
    }
  };

  // Function to handle place selection
  const searchPlace = async (place) => {
    try {
      const res = await axios.get(`https://search.longdo.com/mapsearch/json/search?keyword=${place}&area=10&span=100km&limit=20&key=${mapKey}`);
      setDestPlace(res.data.data[0].name)
      const { lat, lon } = res.data.data[0];
      setDestination({ lat, lon });
      setIsDropdownVisible(false);
    } catch (error) {
      console.error(error);
    }
  };

  // Function to add route from current location to destination
  useEffect(() => {
    // console.log('Destination:', destination);
    // console.log('Source:',source)
    const addRoute = (mapInstance, startLat, startLon, endLat, endLon) => {
      // Clear existing route and marker
      mapInstance.Route.clear();
      if (markerRef.current) {
        mapInstance.Overlays.remove(markerRef.current);
        markerRef.current = null;
      }

      // Create markers for the current location and the destination
      const currentLocationMarker = new window.longdo.Marker({ lon: startLon, lat: startLat });
      markerRef.current = new window.longdo.Marker({ lon: endLon, lat: endLat });

      mapInstance.Overlays.add(currentLocationMarker);
      mapInstance.Overlays.add(markerRef.current);

      // Add the current location and destination as waypoints
      mapInstance.Route.add(currentLocationMarker);
      mapInstance.Route.add(markerRef.current);

      mapInstance.Route.placeholder(document.getElementById('result'));
      // mapInstance.Route.add(Marker);
      // mapInstance.Route.add({ lon: 100, lat: 15 });
      mapInstance.Route.search();
      // Search for a route between the waypoints
      // mapInstance.Route.search((route) => {
      //   if (route) {
      //     console.log('Route data:', route);
      //     const resultDiv = document.getElementById('result');
      //     resultDiv.innerHTML = `Distance: ${route.distance} meters, Duration: ${route.duration} seconds`;
      //   }
      // });
    };

    // Get the current position and add the route
    if (map && destination.lat !== null && destination.lon !== null) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          addRoute(map, position.coords.latitude, position.coords.longitude, destination.lat, destination.lon);
        },
        (error) => {
          console.error('Geolocation is not supported by this browser or permissions were denied.', error);
        }
      );
    }
  }, [destination, map, destination.lat, destination.lon]);


  // save menu
  const [selectedMenuItem, setSelectedMenuItem] = useState(null);
  // const modalRef = useRef(null); // Reference to the modal
  const modalFavRoute = useRef(null);
  const modalProfile = useRef(null);


  const selectMenuItem = (menuItem) => {
    setSelectedMenuItem(menuItem);
    if (menuItem === 'saves') {
      modalFavRoute.current.showModal();
    }
    else if (menuItem === 'profile') {
      modalProfile.current.showModal();
    }
    else if (menuItem === 'home') {
      navigate("/Map");
    }
  };


  const logOut = async () => {
    try {
      await removeCookie('token');
      navigate("/");
    } catch (err) {
        console.log("Error: ", err);
       
    }
};
  //pin path 
  const [showForm, setShowForm] = useState(false);
  const savePathForm = () => {
    setShowForm(!showForm);
  };
  const [selectedPin, setSelectedPin] = useState(null);
  const selectPin = (pin) => {
    setSelectedPin(pin);

  };

  // New state for tracking icon click
  const [isIconClicked, setIsIconClicked] = useState(false);

  // Function to handle icon click
  const handleIconClick = () => {
    AddFavRoute(); // Call your existing function
    setIsIconClicked(!isIconClicked); // Toggle the icon clicked state
  };





  return (
    <div className="flex flex-col h-screen">
      {/* Map Container */}
      <div id="longdo-map" className=" flex basis-3/5 shrink-0" />

      {/* Search Input and Dropdown */}
      <div className="p-4">
        <input
          id="search"
          className="input input-bordered w-full mb-2"
          placeholder="Search"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
        />
        {isDropdownVisible && (
          <ul className="dropdown-content menu p-2 shadow bg-base-100 rounded-box w-full">
            {suggestions.map((val, index) => (
              <li key={index} className="cursor-pointer" onClick={() => searchPlace(val.w)}>{val.w}</li>
            ))}
          </ul>
        )}
        <button className="btn w-full mb-2" onClick={() => {
          searchApi(); savePathForm();
        }}>Search</button>


      </div>
      {/* Result Display */}
      <div className="p-2 mb-20  bg-[#ffedcc] " id="savepath">
        <div className="flex justify-end p-2  ">
          {showForm && (
            <button onClick={handleIconClick} className="btn btn-circle btn-xs mr-5 bg-[#ffedcc]">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">
                <path fill={isIconClicked ? '#000' : '#f80'} d="M4.146.146A.5.5 0 0 1 4.5 0h7a.5.5 0 0 1 .5.5c0 .68-.342 1.174-.646 1.479c-.126.125-.25.224-.354.298v4.431l.078.048c.203.127.476.314.751.555C12.36 7.775 13 8.527 13 9.5a.5.5 0 0 1-.5.5h-4v4.5c0 .276-.224 1.5-.5 1.5s-.5-1.224-.5-1.5V10h-4a.5.5 0 0 1-.5-.5c0-.973.64-1.725 1.17-2.189A5.921 5.921 0 0 1 5 6.708V2.277a2.77 2.77 0 0 1-.354-.298C4.342 1.674 4 1.179 4 .5a.5.5 0 0 1 .146-.354z" />
              </svg>
            </button>
          )}
        </div>
        <div id="result" className="p-2 flex-grow pb-40 bg-[#ffedcc] ">
          {/* Route result will be displayed here */}
        </div>
      </div>


      {/*menu */}
      <div className="fixed bottom-0 inset-x-0 z-10" >
        <ul className="menu p-2 flex flex-row justify-center items-center bg-[#ffedcc] space-x-10 ">
          <li onClick={() => { selectMenuItem('saves').showModal() }}>
            <a className="tooltip  flex flex-col items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-9 fill-current" viewBox="0 0 512 512"><path fill={selectedMenuItem === 'saves' ? '#000' : '#f80'} d="M410.9 0H85.1C72.3 0 61.8 10.4 61.8 23.3V512L248 325.8L434.2 512V23.3c0-12.9-10.4-23.3-23.3-23.3z" /></svg>
              <h2 className={`font-medium ${selectedMenuItem === 'saves' ? 'text-black' : 'text-[#7f7f7f]'}`}>Saves</h2>
            </a>
          </li>

          <li onClick={() => selectMenuItem('home')}>
            <a className="tooltip  flex flex-col items-center" >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-9 w-9 fill-current" viewBox="0 0 24 24"><path fill={selectedMenuItem === 'home' ? '#000' : '#f80'} d="M10 19v-5h4v5c0 .55.45 1 1 1h3c.55 0 1-.45 1-1v-7h1.7c.46 0 .68-.57.33-.87L12.67 3.6c-.38-.34-.96-.34-1.34 0l-8.36 7.53c-.34.3-.13.87.33.87H5v7c0 .55.45 1 1 1h3c.55 0 1-.45 1-1z" /></svg>
              <h2 className={`font-medium ${selectedMenuItem === 'home' ? 'text-black ' : 'text-[#7f7f7f]'}`}>Home</h2>
            </a>
          </li>

          <li onClick={() => selectMenuItem('profile').showModal()}>
            <a className="tooltip  flex flex-col items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-9 w-9 fill-current" viewBox="0 0 24 24"><path fill={selectedMenuItem === 'profile' ? '#000' : '#f80'} fill-rule="evenodd" d="M8 7a4 4 0 1 1 8 0a4 4 0 0 1-8 0Zm0 6a5 5 0 0 0-5 5a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3a5 5 0 0 0-5-5H8Z" clip-rule="evenodd" /></svg>
              <h2 className={`font-medium ${selectedMenuItem === 'profile' ? 'text-black ' : 'text-[#7f7f7f]'}`}>Profile</h2>
            </a>
          </li>
        </ul>
        <dialog ref={modalFavRoute} className="modal">
          <div className="modal-box">
            <form method="dialog">
              <button className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
                onClick={() => modalFavRoute.current.close()}>✕</button>
            </form>
            <h3 className="font-bold text-3xl">Saves</h3>
            <div className="divider"></div>
            {faveRoute.map((val, index) => (
              <p key={index} className="flex items-center p-2 my-2 bg-[#ffedcc] rounded-lg cursor-pointer" onClick={() => { { searchPlace(val) } }}>
                <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-7 w-9 fill-current" viewBox="0 0 32 32"><path fill="#f80" d="m16 24l-6.09-8.6A8.14 8.14 0 0 1 16 2a8.08 8.08 0 0 1 8 8.13a8.2 8.2 0 0 1-1.8 5.13Zm0-20a6.07 6.07 0 0 0-6 6.13a6.19 6.19 0 0 0 1.49 4L16 20.52L20.63 14A6.24 6.24 0 0 0 22 10.13A6.07 6.07 0 0 0 16 4Z" /><circle cx="16" cy="9" r="2" fill="#f80" /><path fill="#f80" d="M28 12h-2v2h2v14H4V14h2v-2H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V14a2 2 0 0 0-2-2Z" /></svg>
                <p>{val}</p>

              </p>
            ))}
          </div>
        </dialog>








        <dialog ref={modalProfile} className="modal">
          <div className="modal-box">
            <form method="dialog">
              <button className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
                onClick={() => modalProfile.current.close()}>✕</button>
            </form>
            <h3 className="font-bold text-lg">Profile</h3>
            <div className="divider"></div>
            <div className='flex flex-col items-center p-4'>
              <img src="https://xsgames.co/randomusers/avatar.php?g=male" alt="profile" className="rounded-full w-24 h-24 mb-4" />
              <p>{cookies.token}</p>
              <button className="btn btn-active mt-3 px-12  btn-neutral" onClick={logOut}>
                <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-7 w-9 fill-current" viewBox="0 0 24 24"><g fill="none" stroke="#f80" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path d="M14 8V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2-2v-2" /><path d="M9 12h12l-3-3m0 6l3-3" /></g></svg>
                Log out
              </button>
            </div>
          </div>
        </dialog>
      </div >
    </div >
  );
}
export default Map;
